#!/usr/bin/env python
# coding: utf-8

# In[3]:


from pymongo import MongoClient

class CRUD:
    def __init__(self, username, password, host, port, db_name, collection_name):
        self.client = MongoClient(f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin")
        self.db = self.client[db_name]
        self.collection = self.db[collection_name]

    def create(self, data):
        try: 
            self.collection.insert_one(data)
            return True
        except Exception as e:
            print(f"An error occurred: {e}")
            return False

    def read(self, query):
        try:
            result = list(self.collection.find(query))
            return result
        except Exception as e:
            print(f"An error occurred: {e}")
            return []

    def update(self, query, new_data):
        try:
            result = self.collection.update_many(query, {"$set": new_data})
            return result.modified_count
        except Exception as e:
            print(f"An error occurred: {e}")
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred: {e}")
            return 0

# Instantiate the CRUD class with MongoDB credentials
crud = CRUD(
    "root",                        # Username
    "zZT91rXhbs",                  # Password
    "nv-desktop-services.apporto.com",  # Host
    30018,                         # Port
    "animal_rescue_db",            # Database name
    "dogs"                         # Collection name
)

# 1. Create a new dog document
data = {
    "name": "Buddy",
    "breed": "Golden Retriever",
    "age": 2,
    "status": "Available"
}
print(crud.create(data))  # Output should be True if the document is successfully inserted

# 2. Read the document just created
query = {"name": "Buddy"}
result = crud.read(query)
print("Read result:", result)

# 3. Update the dog's age
new_data = {"age": 3}
updated_count = crud.update(query, new_data)
print(f"Number of documents updated: {updated_count}")

# 4. Delete the dog document
deleted_count = crud.delete(query)
print(f"Number of documents deleted: {deleted_count}")

# 5. Try reading again to confirm deletion
result = crud.read(query)
print("Read result after delete:", result)


# In[ ]:





# In[ ]:





# In[2]:


data = {
    "name": "Buddy",
    "breed": "Golden Retriever",
    "age": 2,
    "status": "Available"
}
crud.create(data)


# In[ ]:




